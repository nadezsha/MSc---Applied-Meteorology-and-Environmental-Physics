

Homework: 

Same as 6 but compare results and make a presentation about how heating rates are changing with height and what is the effect of cloudiness.

CHECK THE OUTPUT FILES AND THE HOW ZOUT IS DEFINED IN THE INPUT FILE


IMPORTANT NOTE: for multiple runs, check file "bat.bat"



